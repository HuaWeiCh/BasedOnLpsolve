#ifndef __LIB_RECORD_H__
#define __LIB_RECORD_H__

//将结果记录到result缓冲区
extern void record_result(const unsigned short edge);

#endif
